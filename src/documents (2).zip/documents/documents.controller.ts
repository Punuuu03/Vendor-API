import {
  Controller,
  Post,
  Get,
  Put,
  Param,
  Body,
  UseInterceptors,
  UploadedFiles,
  UploadedFile,
} from '@nestjs/common';
import { DocumentsService } from './documents.service';
import { BadRequestException, InternalServerErrorException } from '@nestjs/common';
import { FileInterceptor, FilesInterceptor } from '@nestjs/platform-express';

@Controller('documents')
export class DocumentsController {
  constructor(private readonly documentsService: DocumentsService) { }

  // @Post('upload')
  // @UseInterceptors(
  //   FilesInterceptor('files', 10, {
  //     limits: { fileSize: 500 * 1024 }, // 200KB max file size
  //   }),
  // )
  // async uploadDocuments(
  //   @UploadedFiles() files: Express.Multer.File[],
  //   @Body() body: any,
  // ) {
  //   try {
  //     console.log('📂 Received Files:', files);
  //     console.log('📝 Received Body:', body);

  //     if (!files || files.length === 0) {
  //       throw new BadRequestException('At least one file must be uploaded.');
  //     }

  //     return this.documentsService.uploadDocuments(files, body);
  //   } catch (error) {
  //     console.error('❌ Controller Error:', error);
  //     throw new InternalServerErrorException('File upload failed');
  //   }
  // }



  @Post('upload')
  @UseInterceptors(FileInterceptor('file'))
  async uploadDocuments(
    @UploadedFile() file: Express.Multer.File,
    @Body() body: any,
  ) {
    console.log("📂 Received Files:", file);
    console.log("📝 Received Body:", JSON.stringify(body, null, 2));

    if (!file) {
      console.error('❌ No file uploaded');
      throw new BadRequestException('At least one file must be uploaded.');
    }

    let documentFields;
    try {
      documentFields = JSON.parse(body.document_fields);
    } catch (error) {
      console.error('❌ JSON Parse Error:', error);
      throw new BadRequestException('Invalid JSON format for document_fields.');
    }

    try {
      // Call your S3 upload service
      const fileUrl = await this.uploadToS3(file);

      return {
        message: 'Upload successful',
        fileUrl,
        documentFields,
      };
    } catch (error) {
      console.error('❌ Upload Error:', error);
      throw new InternalServerErrorException('Failed to process document upload');
    }
  }

  private async uploadToS3(file: Express.Multer.File): Promise<string> {
    // Simulate S3 upload
    return 'https://your-s3-url.com/' + file.originalname;
  }



  // 📌 GET API to fetch all documents
  @Get('list')
  async getAllDocuments() {
    try {
      return this.documentsService.getAllDocuments();
    } catch (error) {
      console.error('❌ Error fetching documents:', error);
      throw new InternalServerErrorException('Failed to fetch documents');
    }
  }

  // 📌 PUT API to update document status
  // 📌 PUT API to update document fields dynamically
  @Put('update-fields/:id')
  async updateDocumentFields(
    @Param('id') documentId: number,
    @Body() updatedFields: Record<string, any>,
  ) {
    try {
      console.log('🔄 Updating document fields for:', documentId);
      console.log('📑 New Fields:', updatedFields);

      if (!updatedFields || Object.keys(updatedFields).length === 0) {
        throw new BadRequestException('Updated fields cannot be empty.');
      }

      return this.documentsService.updateDocumentFields(documentId, updatedFields);
    } catch (error) {
      console.error('❌ Error updating document fields:', error);
      throw new InternalServerErrorException('Failed to update document fields');
    }
  }


  // 📌 PUT API to assign Distributor to a Document
  @Put('assign-distributor/:id')
  async assignDistributor(
    @Param('id') documentId: number,
    @Body() body: any, // Log the full body to debug
  ) {
    console.log("📩 Received request body:", body); // Debugging Log

    const distributorId = body.distributor_id;

    if (!distributorId) {
      throw new BadRequestException('Distributor user ID is required.');
    }

    return this.documentsService.assignDistributor(documentId, distributorId);
  }




  // 📌 GET API to fetch documents by distributor_id
  @Get('list/:distributorId')
  async getDocumentsByDistributor(@Param('distributorId') distributorId: string) {
    try {
      if (!distributorId) {
        throw new BadRequestException('Distributor ID is required.');
      }

      return this.documentsService.getAllDocumentsByDistributor(distributorId);
    } catch (error) {
      console.error('❌ Error fetching distributor documents:', error);
      throw new InternalServerErrorException('Failed to fetch documents for distributor');
    }
  }

}
