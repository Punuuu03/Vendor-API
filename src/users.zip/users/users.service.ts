import {
  Injectable,
  ConflictException,
  NotFoundException,
  UnauthorizedException,
  BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User, UserRole, LoginStatus } from './entities/users.entity';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class UsersService {
  userModel: any;
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
    private readonly jwtService: JwtService,
  ) {}

  async register(data: Partial<User>): Promise<User> {
    const { email, password, role } = data;

    if (!password) {
      throw new ConflictException('Password is required');
    }

    const existingUser = await this.userRepository.findOne({ where: { email } });
    if (existingUser) {
      throw new ConflictException('Email already exists');
    }

    const user_login_status =
      role === UserRole.DISTRIBUTOR ? LoginStatus.REJECT : LoginStatus.APPROVE;

    const user = this.userRepository.create({
      ...data,
      password, // Removed hashing
      user_login_status,
    });

    return await this.userRepository.save(user);
  }

  async login(email: string, password: string): Promise<{ token: string; role: UserRole }> {
    const user = await this.userRepository.findOne({ where: { email } });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    if (!password) {
      throw new UnauthorizedException('Password is required');
    }

    if (user.user_login_status === LoginStatus.REJECT) {
      throw new UnauthorizedException('Wait for Admin Approval');
    }

    if (password !== user.password) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const payload = {
      user_id: user.user_id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role,
      user_login_status: user.user_login_status,
      created_at: user.created_at,
    };

    const token = this.jwtService.sign(payload);

    return { token, role: user.role };
  }

  async updateUserStatus(userId: number, status: 'Approve' | 'Reject'): Promise<string> {
    const user = await this.userRepository.findOne({ where: { user_id: userId } });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    if (user.role !== UserRole.DISTRIBUTOR) {
      throw new BadRequestException('Only Distributors can have their status updated');
    }

    user.user_login_status = status as LoginStatus;
    await this.userRepository.save(user);

    return `User status updated to ${status}`;
  }

  async getDistributors(): Promise<User[]> {
    return await this.userRepository.find({
      where: { role: UserRole.DISTRIBUTOR },
    });
  }

  async getRegisteredUsers(): Promise<User[]> {
    return await this.userRepository.find();
  }

  async updatePassword(userId: number, newPassword: string): Promise<string> {
    const user = await this.userRepository.findOne({ where: { user_id: userId } });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    user.password = newPassword; // Removed hashing
    await this.userRepository.save(user);

    return 'Password updated successfully';
  }

  async editUser(userId: number, updateData: Partial<User>): Promise<User> {
    const user = await this.userRepository.findOne({ where: { user_id: userId } });
    if (!user) throw new NotFoundException('User not found');

    await this.userRepository.update(userId, updateData);
    const updatedUser = await this.userRepository.findOne({ where: { user_id: userId } });
    if (!updatedUser) {
      throw new NotFoundException('User not found');
    }
    return updatedUser;
  }

  async deleteUser(userId: number): Promise<string> {
    const result = await this.userRepository.delete(userId);
    if (result.affected === 0) throw new NotFoundException('User not found');
    return 'User deleted successfully';
  }

  async getUserById(userId: string): Promise<User> {
    const user = await this.userModel.findById(userId); // Include password
    if (!user) {
        throw new NotFoundException('User not found');
    }
    return user;
}

}
