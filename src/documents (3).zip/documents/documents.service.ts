import { Injectable, BadRequestException, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Document } from './entities/documents.entity';
import { Express } from 'express';
import { S3Service } from './s3.service';
import * as nodemailer from 'nodemailer';

@Injectable()
export class DocumentsService {
  constructor(
    @InjectRepository(Document)
    private readonly documentRepository: Repository<Document>,

    private readonly s3Service: S3Service
  ) { }

  async getAllDocuments() {
    try {
      const documents = await this.documentRepository.find();
      return { message: 'Documents fetched successfully', documents };
    } catch (error) {
      console.error('❌ Error fetching documents:', error);
      throw new InternalServerErrorException('Could not fetch documents');
    }
  }

  async updateDocumentStatus(documentId: number, status: string) {
    try {
      const document = await this.documentRepository.findOne({ where: { document_id: documentId } });

      if (!document) {
        throw new BadRequestException('Document not found.');
      }

      document.status = status;
      const updatedDocument = await this.documentRepository.save(document);

      return { message: 'Status updated successfully', document: updatedDocument };
    } catch (error) {
      console.error('❌ Error updating status:', error);
      throw new InternalServerErrorException('Could not update document status');
    }
  }


  async uploadDocuments(files: Express.Multer.File[], body: any) {
    try {
      console.log('📂 Received Files:', files);
      console.log('📝 Received Body:', body);

      // ✅ Validate that at least one file is uploaded
      if (!files || files.length === 0) {
        throw new BadRequestException('At least one file must be uploaded.');
      }

      // ✅ Upload files to S3 and store their details
      const documentFiles = await Promise.all(
        files.map(async (file) => {
          const fileUrl = await this.s3Service.uploadFile(file);
          return {
            document_type: file.mimetype,
            file_path: fileUrl,
          };
        })
      );

      // ✅ Parse document_fields safely
      let documentFields = {};
      if (body.document_fields) {
        try {
          documentFields = JSON.parse(body.document_fields);
        } catch (error) {
          console.error('❌ JSON Parse Error:', error);
          throw new BadRequestException('Invalid JSON format for document_fields.');
        }
      }

      // ✅ Ensure user_id is properly parsed
      const userId = parseInt(body.user_id, 10);
      if (isNaN(userId)) {
        throw new BadRequestException('Invalid user_id. It must be a number.');
      }

      // ✅ Check for distributor_id (allow null)
      const distributorId = body.distributor_id || null;

      // ✅ Create the document entry
      const document = this.documentRepository.create({
        user_id: userId,
        category_name: body.category_name || '',
        subcategory_name: body.subcategory_name || '',
        name: body.name || '',
        email: body.email || '',
        phone: body.phone || '',
        address: body.address || '',
        documents: documentFiles,
        status: 'Pending', // Default status
        distributor_id: distributorId,
        document_fields: documentFields, // ✅ Store new document fields
      });

      // ✅ Save document to the database
      const savedDocument = await this.documentRepository.save(document);
      console.log('✅ Document saved successfully:', savedDocument);

      // ✅ Send email notification after successful upload
      await this.sendDocumentSubmissionEmail(savedDocument);

      return { message: 'Upload successful', document: savedDocument };
    } catch (error) {
      console.error('❌ Error saving document:', error);
      throw new InternalServerErrorException('Failed to process document upload');
    }
  }

  // Helper function to send email
  async sendDocumentSubmissionEmail(document: any) {
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'rutujadeshmukh175@gmail.com', // Your email address
        pass: 'hzaj osby vnsh ctyq', // Your email password or app password
      },
    });

    const mailOptions = {
      from: 'rutujadeshmukh175@gmail.com',
      to: document.email, // Recipient email from the document
      subject: 'Application Submitted Successfully',
      text: `Dear ${document.name},

Thank you for applying! Your application for the category "${document.category_name}" has been submitted successfully.

We will review your application and get back to you shortly.

Best regards,
Aaradhya Cyber`,
    };

    try {
      await transporter.sendMail(mailOptions);
      console.log('✅ Email sent successfully');
    } catch (error) {
      console.error('❌ Error sending email:', error);
    }
  }




  async assignDistributor(documentId: number, distributorId: string) {
    try {
      console.log('🔍 Assigning distributor:', distributorId);

      const document = await this.documentRepository.findOne({ where: { document_id: documentId } });

      if (!document) {
        throw new BadRequestException('Document not found.');
      }

      document.distributor_id = distributorId;

      const updatedDocument = await this.documentRepository.save(document);

      console.log('✅ Distributor assigned successfully:', updatedDocument);
      return { message: 'Distributor assigned successfully', document: updatedDocument };
    } catch (error) {
      console.error('❌ Error assigning distributor:', error);
      throw new InternalServerErrorException('Could not assign distributor');
    }
  }

  async getAllDocumentsByDistributor(distributorId: string) {
    try {
      console.log('🔍 Fetching documents for distributor:', distributorId);

      const documents = await this.documentRepository.find({ where: { distributor_id: distributorId } });

      console.log('📄 Documents fetched:', documents);

      return {
        message: 'Documents fetched successfully for distributor',
        documents,
      };
    } catch (error) {
      console.error('❌ Error fetching documents for distributor:', error);
      throw new InternalServerErrorException('Could not fetch documents');
    }
  }

  async getRecentApplications(): Promise<Document[]> {
    return await this.documentRepository
      .createQueryBuilder('document')
      .orderBy('document.uploaded_at', 'DESC') // Sort by uploaded_at in descending order
      .limit(10) // Limit the results to 10
      .getMany();
  }



  // ✅ Update document fields dynamically
  async updateDocumentFields(documentId: number, updatedFields: Record<string, any>) {
    try {
      console.log('🔄 Updating document fields for:', documentId);

      const document = await this.documentRepository.findOne({ where: { document_id: documentId } });

      if (!document) {
        throw new BadRequestException('Document not found.');
      }

      document.document_fields = { ...document.document_fields, ...updatedFields }; // ✅ Merge fields
      const updatedDocument = await this.documentRepository.save(document);

      console.log('✅ Document fields updated successfully:', updatedDocument);
      return { message: 'Document fields updated successfully', document: updatedDocument };
    } catch (error) {
      console.error('❌ Error updating document fields:', error);
      throw new InternalServerErrorException('Could not update document fields');
    }
  }
}
